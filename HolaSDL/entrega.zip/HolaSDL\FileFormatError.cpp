#include "FileFormatError.h"
#include "checkML.h"

FileFormatError::FileFormatError(const std::string msg) : InvadersError(msg) {}