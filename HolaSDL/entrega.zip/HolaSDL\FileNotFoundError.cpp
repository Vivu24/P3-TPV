#include "FileNotFoundError.h"
#include "checkML.h"

FileNotFoundError::FileNotFoundError(const std::string msg) : InvadersError(msg) {}