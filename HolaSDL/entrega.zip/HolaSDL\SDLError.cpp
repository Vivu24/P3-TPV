#include "SDLError.h"
#include "checkML.h"

SDLError::SDLError(const std::string msg) : InvadersError(msg) {}